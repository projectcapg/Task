package com.cg.controller;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.cg.dto.Employee;
import com.cg.service.EmployeeService;
import com.cg.service.EmployeeServiceImpl;

/**
 * Servlet implementation class EmployeeServlet
 */
@WebServlet("/EmployeeServlet")
public class EmployeeServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	EmployeeService service;
	int ID=0;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public EmployeeServlet() {
        super();
        service=new EmployeeServiceImpl();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		HttpSession session=request.getSession(true); // checks for existing sessions for a particular time and if it is available
		                                              // associate request with same else it creates new session
		                                              // getSession(false) will always search for existing session, if it exists 
		                                              // then it will associate else it will return null
		
		String qStr= request.getParameter("action");
		if(qStr.equals("insert"))
		{
			RequestDispatcher dispatch= request.getRequestDispatcher("insert.jsp");
			dispatch.forward(request, response);
		}
		else if(qStr.equals("displayById"))
		{
			RequestDispatcher dispatch= request.getRequestDispatcher("searchById.jsp");
			dispatch.forward(request, response);
			
		}
		else if(qStr.equals("delete"))
		{
			String empId= request.getParameter("id");
			int eId= Integer.parseInt(empId);
			Employee emp= service.getEmployeeById(eId);
			boolean flag=service.deleteEmployee(eId);
			session.setAttribute("emp", emp);
			if(!flag)
			{
				System.out.println("Deletion Unsucessful");
			}
			RequestDispatcher dispatch= request.getRequestDispatcher("deletesuccess.jsp");
			dispatch.forward(request, response);
		}
		else if(qStr.equals("displayAll"))
		{
			ArrayList<Employee> list= service.getAllEmployees();
			session.setAttribute("emplist", list);
			RequestDispatcher dispatch= request.getRequestDispatcher("searchAll.jsp");
			dispatch.forward(request, response);
		}
		else if(qStr.equals("update"))
		{
			String empId= request.getParameter("id");
			ID=Integer.parseInt(empId);
			RequestDispatcher dispatch= request.getRequestDispatcher("updatevalues.jsp");
			dispatch.forward(request, response);
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		HttpSession session=request.getSession(false);
		String qStr= request.getParameter("action");
		if(qStr.equals("insertEmp"))
		{
			String name= request.getParameter("eName");
			String addr= request.getParameter("addr");
			String esal= request.getParameter("eSal");
			int eSal= Integer.parseInt(esal);
			Employee emp= new Employee();
			emp.setEmpAddr(addr);
			emp.setEmpName(name);
			emp.setEmpSal(eSal);
			Employee ref= service.addEmployee(emp);
			if(ref!=null)
			{
				session.setAttribute("emp", ref);
				RequestDispatcher dispatch= request.getRequestDispatcher("insertSuccess.jsp");
				dispatch.forward(request, response);
			}
		}
		else if(qStr.equals("searchById"))
		{
			System.out.println("Hi from searchById");
			String empId= request.getParameter("id");
			int eId= Integer.parseInt(empId);
			Employee emp=service.getEmployeeById(eId);
			session.setAttribute("empById", emp);
			RequestDispatcher dispatch= request.getRequestDispatcher("success.jsp");
			dispatch.forward(request, response);
		}
		else if(qStr.equals("delete"))
		{
			String empId= request.getParameter("id");
			System.out.println(empId);
			int eId= Integer.parseInt(empId);
			Employee emp= service.getEmployeeById(eId);
			boolean flag=service.deleteEmployee(eId);
			session.setAttribute("emp", emp);
			if(!flag)
			{
				System.out.println("Deletion Unsucessful");
			}
			RequestDispatcher dispatch= request.getRequestDispatcher("deletesuccess.jsp");
			dispatch.forward(request, response);
		}
		else if(qStr.equals("updateEmp"))
		{
			String name= request.getParameter("eName");
			String addr= request.getParameter("addr");
			String esal= request.getParameter("eSal");
			int eSal= Integer.parseInt(esal);
			Employee emp= new Employee();
			emp.setEmpAddr(addr);
			emp.setEmpName(name);
			emp.setEmpSal(eSal);
			emp.setEmpId(ID);
			boolean flag= service.updateEmployee(emp);
			if(flag)
			{
				ArrayList<Employee> list= service.getAllEmployees();
				session.setAttribute("emplist", list);
				RequestDispatcher dispatch= request.getRequestDispatcher("searchAll.jsp");
				dispatch.forward(request, response);
			}
		}
	}

}
