package com.cg.dao;

import java.sql.*;
import java.util.ArrayList;

import com.cg.dto.Employee;
import com.cg.util.DBUtil;

public class EmployeeDaoImpl implements EmployeeDao{
	
	Connection con;

	public EmployeeDaoImpl()
	{
		con=DBUtil.getConnection();
	}

	@Override
	public Employee addEmployee(Employee emp) {
		// TODO Auto-generated method stub
		Employee ref=null;
		String qry="INSERT INTO EMPDETAILS VALUES(EMPID_SEQ.NEXTVAL,?,?,?)";
		try
		{
			PreparedStatement st=con.prepareStatement(qry);
			st.setString(1, emp.getEmpName());
			st.setInt(2, emp.getEmpSal());
			st.setString(3, emp.getEmpAddr());
			int row=st.executeUpdate();
			if(row>0)
			{
				emp.setEmpId(getEmployeeId());
				ref=emp;
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return ref;
	}
	
	public int getEmployeeId()
	{
		int id=0;
		String qry="SELECT EMPID_SEQ.CURRVAL FROM DUAL";
		try
		{
			Statement st=con.createStatement();
			ResultSet rs=st.executeQuery(qry);
			if(rs.next())
			{
				id=rs.getInt(1);
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return id;
	}

	@Override
	public Employee getEmployeeById(int empId) {
		// TODO Auto-generated method stub
		Employee ref=null;
		String qry="SELECT * FROM EMPDETAILS WHERE EMPID=?";
		try
		{
			System.out.println(empId);
			PreparedStatement st=con.prepareStatement(qry);
			st.setInt(1, empId);
			ResultSet rs=st.executeQuery();
			if(rs.next())
			{
				ref=new Employee(rs.getInt(1),rs.getString(2),rs.getInt(3),rs.getString(4));
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return ref;
	}

	@Override
	public ArrayList<Employee> getAllEmployees() {
		// TODO Auto-generated method stub
		
		Employee emp=null;
		String qry="SELECT * FROM EMPDETAILS";
		ArrayList<Employee> list= new ArrayList<Employee>();
		try
		{
			Statement st=con.createStatement();
			ResultSet rs=st.executeQuery(qry);
			
			while(rs.next())
			{
				System.out.println(rs.getInt(1)+rs.getString(2)+rs.getInt(3)+rs.getString(4));
				emp= new Employee(rs.getInt(1),rs.getString(2),rs.getInt(3),rs.getString(4));
				list.add(emp);
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return list;
	}

	@Override
	public boolean deleteEmployee(int empId) {
		// TODO Auto-generated method stub
		boolean flag=false;
		String qry="DELETE FROM EMPDETAILS WHERE EMPID=?";
		try
		{
			PreparedStatement st=con.prepareStatement(qry);
			st.setInt(1, empId);
			int d=st.executeUpdate();
			if(d==1)
			{
				flag=true;
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return flag;
	}

	@Override
	public boolean updateEmployee(Employee emp) {
		// TODO Auto-generated method stub
		boolean flag= false;
		String qry="UPDATE EMPDETAILS SET EMPNAME=?,EMPSAL=?,EMPADDR=? WHERE EMPID=?";
		try
		{
			PreparedStatement st=con.prepareStatement(qry);
			st.setString(1, emp.getEmpName());
			st.setInt(2, emp.getEmpSal());
			st.setString(3, emp.getEmpAddr());
			st.setInt(4, emp.getEmpId());
			int row= st.executeUpdate();
			if(row>0)
			{
				flag=true;
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return flag;
	}
	
}
