package com.cg.util;

import java.sql.*;

public class DBUtil {
	
	static Connection con;
	static
	{
		try
		{
			 Class.forName("oracle.jdbc.driver.OracleDriver");
			 String url="jdbc:oracle:thin:@10.51.103.201:1521:ORCL11G";
			 String user="Lab2Etrg16";
			 String pass="lab2eoracle";
			 con=DriverManager.getConnection(url,user,pass);
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	public static Connection getConnection() {
		// TODO Auto-generated method stub
		return con;
	}

}
