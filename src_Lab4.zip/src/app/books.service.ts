import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http'; // important to import
import { Observable, throwError } from 'rxjs';
import { retry, catchError } from 'rxjs/operators';
import { Books } from './books';

@Injectable({
  providedIn: 'root'
})
export class BooksService {

  url = '../assets/booklist.json';
  books: Books[];
  filterData: Books[];
  filter: Books;
  book: Books;
  index: number;
  constructor(private http: HttpClient) {
    this.getBooks();
  } // initializing the Http object

  getData(): Observable<Books[]> {
    return this.http.get<Books[]>(this.url).pipe(retry(2), catchError(this.handleError));
  } // send the Http request to get the array of books from the json file

  handleError(error) {
    console.log(error);
    return throwError(error);
  } // error handling ex 404 error etc

  getBooks() {
    this.getData().subscribe((data: Books[]) => this.books = data);
    console.log('Data: ' + this.books);
  } // convert into books array

  getAllBooks() {
    return this.books;
  }

  setSearchedData(data) {
    this.filterData = data;
  }
  getSearch() {
    return this.filterData;
  }
}
