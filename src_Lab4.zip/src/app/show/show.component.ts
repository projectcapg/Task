import { Component, OnInit } from '@angular/core';
import { Books } from '../books';
import { BooksService } from '../books.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-show',
  templateUrl: './show.component.html',
  styleUrls: ['./show.component.css']
})
export class ShowComponent implements OnInit {

  books: Books[];

  constructor(private bookService: BooksService, private router: Router) { }

  ngOnInit() {
    this.books = this.bookService.getAllBooks();
  }

}
