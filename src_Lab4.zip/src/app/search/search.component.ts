import { Component, OnInit } from '@angular/core';
import { Books } from '../books';
import { BooksService } from '../books.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-search',
  templateUrl: './search.component.html',
  styleUrls: ['./search.component.css']
})
export class SearchComponent implements OnInit {

  books: Books[];
  searchText1;
  searchText2;
  searchText3;
  searchText4;

  constructor(private bookService: BooksService, private router: Router) { this.bookService = bookService; }

  ngOnInit() {
    this.books = this.bookService.getAllBooks();
  }

}
