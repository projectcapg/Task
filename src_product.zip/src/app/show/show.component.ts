import { Component, OnInit } from '@angular/core';
import { Product } from '../product';
import { ProductService } from '../product.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-show',
  templateUrl: './show.component.html',
  styleUrls: ['./show.component.css']
})
export class ShowComponent implements OnInit {
  products: Product[];

  constructor(private prodService: ProductService, private router: Router) { }

  ngOnInit() {
    this.products = this.prodService.getAllProducts();
  }
  delete(i: number) {
    this.prodService.deleteProduct(i);
  }


}
