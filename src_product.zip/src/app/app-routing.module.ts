import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ShowComponent } from './show/show.component';
import { AddproductComponent } from './addproduct/addproduct.component';
import { SearchComponent } from './search/search.component';
import { ShowsearchdataComponent } from './showsearchdata/showsearchdata.component';



const routes: Routes = [
  { path: '', redirectTo: 'add', pathMatch: 'full' }, // default page if no path is selected
  { path: 'add', component: AddproductComponent },
  { path: 'show', component: ShowComponent },
  { path: 'search', component: SearchComponent },
  { path: 'showsearch', component: ShowsearchdataComponent },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
