import { Component, OnInit } from '@angular/core';
import { Product } from '../product';
import { ProductService } from '../product.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-search',
  templateUrl: './search.component.html',
  styleUrls: ['./search.component.css']
})
export class SearchComponent implements OnInit {

  selectedVal;
  products: Product[];
  searchedProduct: Product[];

  constructor(private prodService: ProductService, private router: Router) { this.prodService = prodService; }


  ngOnInit() {
    this.products = this.prodService.getAllProducts();
  }

  filterData(value: string) {
    this.searchedProduct = this.products.filter(product => product.brand.toLowerCase() === (value.toLowerCase()));
    this.prodService.setSearchedData(this.searchedProduct);
    if (this.searchedProduct.length > 0) {
      alert('Data found!');
      this.router.navigate(['showsearch']);
    } else {
      alert('Name not found please try with other names');
    }
  }

}
