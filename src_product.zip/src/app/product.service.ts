import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http'; // important to import
import { Observable, throwError } from 'rxjs';
import { retry, catchError } from 'rxjs/operators';
import { Product } from './product';

@Injectable({
  providedIn: 'root'
})
export class ProductService {
  url = '../assets/product.json';
  products: Product[];
  status: string;
  filterData: Product[];
  constructor(private http: HttpClient) {
    this.getProducts();
  } // initializing the Http object

  getData(): Observable<Product[]> {
    return this.http.get<Product[]>(this.url).pipe(retry(2), catchError(this.handleError));
  } // send the Http request to get the array of products from the json file

  handleError(error) {
    console.log(error);
    return throwError(error);
  } // error handling ex 404 error etc

  getProducts() {
    this.getData().subscribe((data: Product[]) => this.products = data);
    console.log('Data: ' + this.products);
  } // convert into products array

  getAllProducts() {
    return this.products;
  }
  deleteProduct(i) {
    this.products.splice(i, 1);
  }
  addProduct(product: Product) {
    this.products.push(product);
  }
  setSearchedData(data) {
    this.filterData = data;
  }
  getSearch() {
    return this.filterData;
  }

}
