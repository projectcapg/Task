import { Component, OnInit } from '@angular/core';
import { Product } from '../product';
import { ProductService } from '../product.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-addproduct',
  templateUrl: './addproduct.component.html',
  styleUrls: ['./addproduct.component.css']
})
export class AddproductComponent implements OnInit {

  prod: Product = { id: null, name: '', price: null, brand: '' };
  constructor(private prodService: ProductService, private router: Router) { }

  add() {
    this.prodService.addProduct(this.prod);
    this.router.navigate(['show']);
  }

  ngOnInit() {
  }

}
