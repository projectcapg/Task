import { Component, OnInit } from '@angular/core';
import { Product } from '../product';
import { ProductService } from '../product.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-showsearchdata',
  templateUrl: './showsearchdata.component.html',
  styleUrls: ['./showsearchdata.component.css']
})
export class ShowsearchdataComponent implements OnInit {
  searchedData: Product[];
  allData: Product[];

  constructor(private prodService: ProductService, private router: Router) { }

  ngOnInit() {
    this.searchedData = this.prodService.getSearch();
    this.allData = this.prodService.getAllProducts();
  }

  delete(idname) {
    for (let i = 0; i < this.allData.length; i++) {
      if (idname === this.allData[i].id) {
        this.prodService.deleteProduct(i);
        this.router.navigate(['show']);
        break;
       }
    }
    // this.prodService.deleteProduct(i);
    // this.router.navigate(['show']);
  }

}
