package com.cg.dao;

import java.io.IOException;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

import com.cg.dto.Application;
import com.cg.dto.ProgramOffered;
import com.cg.dto.ProgramScheduled;
import com.cg.util.DBUtil;

public class AdminDAOImpl implements AdminDAO {
	
	Connection con =null;	

	public AdminDAOImpl() throws IOException {
		super();
		con = DBUtil.getConnection() ;
	}

	@Override
	public boolean checkLogin(String loginId, String password) {
		String qry = "select login_id,password from users where role = admin";
		boolean check = false;
		try{
			Statement st = con.createStatement();
			ResultSet rs = st.executeQuery(qry);
			while(rs.next()){
				if(loginId.equals(rs.getString(1)) && password.equals(rs.getString(2))){
					check = true;
					break;
				}
			}
		}
		catch(Exception e){
			System.out.println("Something went Wrong");
		}
		return check;
	}

	@Override
	
	public void addProgram(ProgramOffered obj) {
		String qry = "insert into Programs_Offered values(?,?,?,?,?)";
		try{
			PreparedStatement pst = con.prepareStatement(qry);
			pst.setString(1, obj.getProgramName());
			pst.setString(2, obj.getDescription());
			pst.setString(3, obj.getApplicantEligibility());
			pst.setInt(4, obj.getDuration());
			pst.setString(5, obj.getDegreeCertificateOffered());
			pst.execute();
		}
		catch(Exception e){
			System.out.println("Not entered");
		}
	}

	@Override
	public void deleteProgram(String programName) {
		String qry = "delete Programs_Offered where ProgramName= ? ";
		try{
			PreparedStatement pst = con.prepareStatement(qry);
			pst.setString(1, programName);
			pst.execute();
		}
		catch(Exception e){
			System.out.println("Program does not get deleted from all program ");
		}
	}


	@Override
	public void scheduleProgram(ProgramScheduled obj) {
		String qry = "insert into Programs_Scheduled  values(?,?,?,?,?,?)";
		try{
			PreparedStatement pst = con.prepareStatement(qry);
			pst.setString(1, obj.getScheduledProgramId());
			pst.setString(2, obj.getProgramName());
			pst.setString(3, obj.getLocation());
			pst.setDate(4, obj.getStartDate());
			pst.setDate(5, obj.getEndDate());
			pst.setInt(6, obj.getSessionsPerWeek());
			pst.execute();
		}
		catch(Exception e){
			System.out.println("program does not get scheduled");
		}
	}


	@Override
	public ArrayList<ProgramScheduled> getScheduledProgram(Date startDate,
			Date endDate) {
		String qry = "select * from Programs_Scheduled where start_date >= ? and end_date<= ? ";
		ArrayList<ProgramScheduled> list = new ArrayList<ProgramScheduled>();
		//PreparedStatement pst = null ;
		try{
			//System.out.println(startDate + "  " + endDate);
			PreparedStatement pst = con.prepareStatement(qry);
			
			pst.setDate(1, startDate);
			pst.setDate(2, endDate);
			ResultSet rs = pst.executeQuery();
			while(rs.next()){
				list.add(new ProgramScheduled(rs.getString(1) , rs.getString(2), rs.getString(3), rs.getDate(4), rs.getDate(5), rs.getInt(6)));
			}
		}
		catch(Exception e){
			System.out.println("scheduled program problem");
			e.printStackTrace();
		}
		
		return list;
	}

	@Override
	public ArrayList<Application> getStatus(String status) {
		String qry = "select * from application where status = ?";
		ArrayList<Application> list = new ArrayList<Application>();
		try{
			System.out.println(status);
			PreparedStatement pst = con.prepareStatement(qry);
			pst.setString(1, status);
			ResultSet rs = pst.executeQuery();
			while (rs.next()) {
				Application ps = new Application(rs.getInt(1), rs.getString(2), rs.getDate(3), rs.getString(4), rs.getInt(5), rs.getString(6), rs.getString(7),rs.getString(8), rs.getString(9), rs.getDate(10));
				list.add(ps);
			}	
		}
		
		catch(Exception e){
			System.out.println("Program Is not Scheduled");
			e.printStackTrace();
		}
		
		return list;
	}
}