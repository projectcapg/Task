package com.cg.dao;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.cg.util.DBUtil;

public class UserDaoImpl implements UserDao{
	
	public UserDaoImpl()
	{
		
	}

	@Override
	public String ReturnRole(String loginId, String password) {
		// TODO Auto-generated method stub
		Connection con=null;
		ResultSet rs = null;
		PreparedStatement pstmt = null;
		String qry1="SELECT PASSWORD FROM USERS WHERE LOGIN_ID=?";
		String qry2="SELECT ROLE FROM USERS WHERE LOGIN_ID=?";
		
		try
		{
			con=DBUtil.getConnection();
			pstmt = con.prepareStatement(qry1);
			pstmt.setString(1, loginId);
			rs=pstmt.executeQuery();
			rs.next();
			String checkPass=rs.getString(1);
//			System.out.println(checkPass+"   "+password);
			if(checkPass.equals(password))
			{
				pstmt = con.prepareStatement(qry2);
				pstmt.setString(1, loginId);
				rs=pstmt.executeQuery();
				rs.next();
				return rs.getString(1);
				
			}
			
			else
			{
				return "Invalid Login Id or Password";
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
		return null;
	}

}
