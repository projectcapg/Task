package com.cg.client;
import java.util.Scanner;

import com.cg.dao.UserDao;
import com.cg.dao.UserDaoImpl;
import com.cg.service.MACService;
import com.cg.service.MACServiceImpl;

public class MemberLoginMain {

	MACService service=null;
	UserDao chk=null;
	public void Login()
	{
		chk=new UserDaoImpl();
		int LoginAttempt=0;
		int choice=-1;
		service= new MACServiceImpl();
		Scanner sc = new Scanner(System.in);
		while(true)
		{
			if(LoginAttempt>2)
			{
				System.out.println("Too many Attempts! \n Exiting Application...");
				sc.close();
				System.exit(0);
			}
			else
			{
				System.out.println("You have "+(3-LoginAttempt)+" attempts remaining");
				System.out.println("Login Id: ");
				String login=sc.next();
				System.out.println("Password:");
				String pass=sc.next();
				String message=chk.ReturnRole(login, pass);
				//System.out.println(message);
				if(message.equals("MAC"))
				{
					System.out.println("You are now Logged in as a Member of Admission Committe(MAC) : ");
					MACShow();
					return;
				}
				else if(message.equals("Admin"))
					{
					System.out.println("You are now Logged in as an admin ");
					adminShow();
					return;
				}
				else
					System.out.println(message);
				
			    LoginAttempt++;
			}
		}
	}
	private void adminShow() {
		// TODO Auto-generated method stub
		System.out.println("Hi from the admin");
		return;
		
	}
	private void MACShow() {
		// TODO Auto-generated method stub
		System.out.println("Hi from the MAC");
		return;
		
	}
}
