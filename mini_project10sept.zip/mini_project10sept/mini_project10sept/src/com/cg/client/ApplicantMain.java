package com.cg.client;
import java.time.LocalDate;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

import com.cg.dto.Application;
import com.cg.dto.ProgramScheduled;
import com.cg.service.ApplicantService;
import com.cg.service.ApplicantServiceImpl;
import com.cg.util.MyStringDateUtil;

public class ApplicantMain {

	ApplicantService service=null;
	public void NewApplication()
	{
		Scanner sc=new Scanner(System.in);
		service= new ApplicantServiceImpl();
		int choice=-1;
		while(true)
		{
			System.out.println("\n\n**************************************************");
			System.out.println("\nSelect an Option:");
			System.out.println("\t1. View List of Scheduled Programs\n\t"
									+ "2. Apply for a Program\n\t"
									+ "3. Track Application Status");
			System.out.println("\n**************************************************");
			System.out.println("Enter 0 to Return");
			System.out.println("Enter your choice:");
			choice=Integer.parseInt(sc.nextLine());
			
			switch(choice) {
			
				case 1:
						System.out.println("\n\n*****List of Scheduled Programs****");
						List<ProgramScheduled> list = service.getAllScheduledPrograms();
						Iterator<ProgramScheduled> iterator = list.iterator();						
						while (iterator.hasNext()) 
					         	System.out.println(iterator.next()); 
						break;
						
				case 2:
						System.out.println("\n\nEnter details to apply for the selected Program.");
						Application applicant = new Application();
						
						System.out.println("\t\t1. Full Name: ");						
						applicant.setFullName(sc.nextLine());
						
						System.out.println("\t\t2. Date of Birth in dd-MM-yyyy format:");
						String date = sc.nextLine();
						LocalDate ldate =MyStringDateUtil.fromStringToLocalDate(date);
					    //LocalDate ldate = MyStringDateUtil.fromSqlToLocalDate(MyStringDateUtil.fromStringToSqlDate(date));
						applicant.setDateOfBirth(ldate);
						
						System.out.println("\t\t3. Choose Highest Qualification..."
								+ "\n\t\t\t (a) B.Tech"
								+ "\n\t\t\t (b) B.Sc"
								+ "\n\t\t\t (c) B.Pharm."
								+ "\n\t\t\t (d) BCA"
								+ "\n\t\t\t (e) MCA");
						String qualification=null;
						char ch = sc.nextLine().charAt(0);
						if(ch=='a')
							qualification = "B.Tech";
						else if(ch=='b')
							qualification = "B.Sc";
						else if(ch=='c')
							qualification = "B.Pharm";
						else if(ch=='d')
							qualification = "BCA";
						else if(ch=='e')
							qualification = "MCA";
						applicant.setHighestQualification(qualification);
						
						System.out.println("\n\t\t4. Marks Obtained (*/100):");
						applicant.setMarksObtained(Integer.parseInt(sc.nextLine()));
						
						System.out.println("\n\t\t5. Goals:");
						applicant.setGoals(sc.nextLine());
						
						System.out.println("\n\t\t6. Email-Id:");
						applicant.setEmailId(sc.nextLine());
						
						System.out.println("\n\t\t7. Scheduled Program Id:");
						System.out.println("\n\t\t a) MATHS");
						System.out.println("\n\t\t b) PHYSICS");
						String program=null;
						char ch2 = sc.nextLine().charAt(0);
						if(ch2=='a')
							program = "MATHS";
						else if(ch2=='b')
							program = "PHYSI";
						applicant.setScheduledProgramId(program);	
						//applicant.setScheduledProgramId(sc.nextLine());
						
						if(service.addApplication(applicant)!=0) {
							
							System.out.println("Application added Successfully!");
							//System.out.println("Your application Id is: "+applicant.getApplicationId());
						}
						else
							System.out.println("Error! during application process.");
						
						break;
						
				case 3:
						System.out.println("\n\t\tEnter the application id:");
						int id = sc.nextInt();
						String status= service.applicationStatus(id);
						System.out.println("Applicaion status: " +status);
						break;
						
				case 0:
						return;
					
				default: 
						System.out.println("Sorry ! invalid keystroke... try again");
						
			}			
		}		
	}
}
