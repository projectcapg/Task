import { Component, OnInit, Input, Output } from '@angular/core';
import { EmployeeService } from '../employee.service';
import { EventEmitter } from '@angular/core';

@Component({
  selector: 'app-employeecount',
  templateUrl: './employeecount.component.html',
  styleUrls: ['./employeecount.component.css']
})
export class EmployeecountComponent implements OnInit {
  constructor() { }

  @Input()
  all: number;
  @Input()
  male: number;
  @Input()
  female: number;
  selectedVal = 'all';
  @Output()
  notify: EventEmitter<string> = new EventEmitter<string>();

  changeMe() {
    this.notify.emit(this.selectedVal);
  }

  ngOnInit() {
  }


}
