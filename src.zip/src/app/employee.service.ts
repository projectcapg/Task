import { Injectable } from '@angular/core';
import { Employee } from './employee';

@Injectable({
  providedIn: 'root'
})
export class EmployeeService {

  private employees: Employee[] = [{ eid: 123, name: 'Priya', salary: 2321, gender: 'Female' },
  { eid: 142, name: 'Riya', salary: 4500, gender: 'Female' }, { eid: 121, name: 'Hari', salary: 9500, gender: 'Male' },
  { eid: 201, name: 'Shivendra', salary: 8000, gender: 'Male' }, { eid: 199, name: 'Smith', salary: 7800, gender: 'Male' }];
  constructor() { }

  getEmployees(): Employee[] {
    return this.employees;
  }
  addEmployee(emp: Employee) {
    this.employees.push(emp);
    return true;
  }

  deleteEmployee(i: number) {
    this.employees.splice(i, 1);
  }
}
