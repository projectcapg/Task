import { Component, OnInit } from '@angular/core';
import { EmployeeService } from '../employee.service';
import { Employee } from '../employee';

@Component({
  selector: 'app-employeelist',
  templateUrl: './employeelist.component.html',
  styleUrls: ['./employeelist.component.css']
})
export class EmployeelistComponent implements OnInit {
  employees: Employee[];
  selected = 'all';

  constructor(private employeeService: EmployeeService) {
    this.employeeService = employeeService;
  }

  ngOnInit() {
    this.employees = this.employeeService.getEmployees();
  }
  EmpChange(selectedVal) {
    this.selected = selectedVal;
  }
  delete(i: number) {
    if (confirm('Are you sure you want to delete?')) {
      this.employeeService.deleteEmployee(i);
    }
  }
  totalCount(): number {
    return this.employees.length;
  }
  maleCount(): number {
    return this.employees.filter(e => e.gender === 'Male').length;
  }
  femaleCount(): number {
    return this.employees.filter(e => e.gender === 'Female').length;
  }
}
