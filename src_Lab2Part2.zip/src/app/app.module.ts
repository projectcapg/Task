import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { ShowallComponent } from './showall/showall.component';
import { OrderModule } from 'ngx-order-pipe';
import { ShowComponent } from './show/show.component';

@NgModule({
  declarations: [
    AppComponent,
    ShowallComponent,
    ShowComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule, OrderModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
