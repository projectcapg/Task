import java.util.Scanner;

public class ApplicantMain {

	//ApplicantService service=null;
	public void NewApplication()
	{
		Scanner sc=new Scanner(System.in);
		//service= new ApplicantServiceImpl();
		int choice=-1;
		while(true)
		{
			System.out.println("\n\n**************************************************");
			System.out.println("\nSelect an Option:");
			System.out.println("\t1. View List of Scheduled Programs\n\t"
					+ "2. Apply for a Program\n\t"
					+ "3. Track Application Status");
			System.out.println("\n**************************************************");
			System.out.println("Enter 0 to Exit");
			System.out.println("Enter your choice:");
			choice=sc.nextInt();
		}
		
	}
}
