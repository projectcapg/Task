import java.util.Scanner;

public class MemberLoginMain {

	//MemberLoginService service=null;
	public void Login()
	{
		int LoginAttempt=0;
		int choice=-1;
		//service= new MemberServiceImpl();
		Scanner scan= new Scanner(System.in);
		while(true)
		{
			if(LoginAttempt>2)
			{
				System.out.println("Too many Attempts! /n Exiting Application...");
				System.exit(0);
			}
			else
			{
				System.out.println("You have "+(3-LoginAttempt)+" attempts remaining");
				System.out.println("Login Id: ");
				String login=scan.next();
				System.out.println("Password:");
				String pass=scan.next();
			}
		}
	}
}
