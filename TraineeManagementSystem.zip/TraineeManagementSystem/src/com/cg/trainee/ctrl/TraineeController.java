package com.cg.trainee.ctrl;

import java.util.ArrayList;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;




import com.cg.trainee.dto.Login;
import com.cg.trainee.dto.Trainee;
import com.cg.trainee.service.TraineeService;



@Controller
public class TraineeController {
	
	@Autowired
	TraineeService logS;
	
	Trainee toBeDeleted;

	public TraineeService getLogS() {
		return logS;
	}

	public void setLogS(TraineeService logS) {
		this.logS = logS;
	}

	//**********************************************SHOWLOGINPAGE*********************************************************************
	@RequestMapping(value="/ShowLoginPage")
	public String displayLoginPage(Model model)
	{
		Login lg=new Login();
		model.addAttribute("log",lg);
		return "Login";
	}
	
	// ********************************************VALIDATEUSER**********************************************************************
	
	@RequestMapping(value="/ValidateUser")
	public String ValidateUser(@ModelAttribute("log") Login lg,BindingResult result, Model model)
	{
		System.out.println("user ENtered: "+lg);
		if(logS.validateUser(lg))
		{
			return "Success";
		}
		else
		{
			model.addAttribute("MsgObj","Please check your credentials");
			return "Login";
		}
	}
	
	//***************************************************ADDTRAINEE*********************************************************************
	
	@RequestMapping(value="/AddTraineePage")
	public String addTraineeDetails(Model model)
	{
		Trainee trainee=new Trainee();
	     
		 ArrayList<String> cityList=new ArrayList<String>();
		 cityList.add("Chennai");
		 cityList.add("Bengaluru");
		 cityList.add("Mumbai");
		 cityList.add("Pune");
		 model.addAttribute("cityListObj",cityList);
		 
		 ArrayList<String> skillList=new ArrayList<String>();
		 skillList.add("Java");
		 skillList.add("Oracle");
		 skillList.add("Html");
		 skillList.add("BI");
		 skillList.add("Testing");
		 model.addAttribute("skillListObj",skillList);
		 model.addAttribute("traineeObj",trainee);
		  return "AddTrainee";
	}
	
	@RequestMapping(value="/AddTraineeDetails")
	public String insertUserDetails(@ModelAttribute("traineeObj") Trainee reg, BindingResult result, Model model)
	{
	
		logS.addTrainee(reg);
		model.addAttribute("MsgObj","Trainee Added!");
		return "Success";
	}
	
	//************************************************SHOWALLTRAINEES************************************************
	
	@RequestMapping(value="/SearchAllTraineePage")
	public String showAllTraineeDetails(Model model)
	{
		ArrayList<Trainee> list=logS.getAllTraineeDetails();
		model.addAttribute("TraineeList",list);
		return "ShowAll";
	}
	
	//************************************************SEARCHTRAINEEBYID***********************************************
	
	@RequestMapping(value="/SearchTraineePage")
	public String searchTraineeById(@ModelAttribute("traineeObj") Trainee reg,Model model)
	{
		if(reg.getTraineeId()!=0)
//		Trainee train=new Trainee();
//		model.addAttribute("ID",train);
		{
			Trainee found=logS.getTraineeById(reg.getTraineeId());
			if(found==null)
			{
				model.addAttribute("ID",reg.getTraineeId());
				return "Error";
			}
			else
			{
			model.addAttribute("Trainee",found);
			return "SearchById";
			}
		}
		else
		{
			Trainee train=new Trainee();
		model.addAttribute("traineeObj",train);
		return "SearchById";
		}
	}
	
	//***********************************************DELETETRAINEE********************************************************
	
	@RequestMapping(value="/DeleteTraineePage")
	public String deleteTraineeById(@ModelAttribute("traineeObj") Trainee reg,Model model)
	{
		if(reg.getTraineeId()!=0)
		{
			Trainee found=logS.getTraineeById(reg.getTraineeId());
			if(found==null)
			{
				model.addAttribute("ID",reg.getTraineeId());
				return "Error";
			}
			else
			{
			toBeDeleted=found;
			model.addAttribute("Trainee",found);
			return "deleteTrainee";
			}
		}
		else
		{
			Trainee train=new Trainee();
		model.addAttribute("traineeObj",train);
		return "deleteTrainee";
		}
	}
	
	@RequestMapping(value="/deleteSuccess")
	public String deleteSuccess(Model model)
	{
		boolean flag=logS.deleteTraineeById(toBeDeleted.getTraineeId());
		if(flag)
		{
			model.addAttribute("MsgObj","Trainee Deleted!");
			return "Success";
		}
		else
		{
			return "Error";
		}
	}
	//*******************************************UPDATETRAINEE******************************************************************************
	
	@RequestMapping(value="/UpdateTraineePage")
	public String updateTrainee(@ModelAttribute("traineeObj") Trainee reg,Model model)
	{
		if(reg.getTraineeId()!=0)
		{
			Trainee found=logS.getTraineeById(reg.getTraineeId());
			if(found==null)
			{
				model.addAttribute("ID",reg.getTraineeId());
				return "Error";
			}
			else
			{
			System.out.println("Update trainee found:"+found);
			model.addAttribute("traineeObj",found);
			ArrayList<String> cityList=new ArrayList<String>();
			 cityList.add("Chennai");
			 cityList.add("Bengaluru");
			 cityList.add("Mumbai");
			 cityList.add("Pune");
			 model.addAttribute("cityListObj",cityList);
			 ArrayList<String> skillList=new ArrayList<String>();
			 skillList.add("Java");
			 skillList.add("Oracle");
			 skillList.add("Html");
			 skillList.add("BI");
			 skillList.add("Testing");
			 model.addAttribute("skillListObj",skillList);
			return "UpdateForm";
		}
		}
		else
		{
			Trainee train=new Trainee();
		model.addAttribute("traineeObj",train);
		return "UpdateForm";
		}
	}
	
	
	@RequestMapping(value="/UpdateDetails")
	public String Updation(@ModelAttribute("traineeObj") Trainee reg,Model model)
	{
		logS.updateTrainee(reg);
		model.addAttribute("MsgObj","Trainee Updated!");
		return "Success";
	}
}
