package com.cg.trainee.service;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.trainee.dao.TraineeDao;
import com.cg.trainee.dto.Login;
import com.cg.trainee.dto.Trainee;

@Service
public class TraineeServiceImpl implements TraineeService{

	@Autowired
	TraineeDao dao;
	
	
	
	public TraineeDao getDao() {
		return dao;
	}



	public void setDao(TraineeDao dao) {
		this.dao = dao;
	}



	@Override
	public boolean validateUser(Login lg) {
		// TODO Auto-generated method stub
		Login user=dao.getUserById(lg.getUsername());
		if(lg.getUsername().equalsIgnoreCase(user.getUsername())&&lg.getPassword().equalsIgnoreCase(user.getPassword()) )
		{
			return true;
		}
		else
		{
		return false;
		}
	}



	@Override
	public Login getUserById(String username) {
		// TODO Auto-generated method stub
		return dao.getUserById(username);
	}



	@Override
	public Trainee addTrainee(Trainee trainee) {
		// TODO Auto-generated method stub
		return dao.addTrainee(trainee);
	}



	@Override
	public ArrayList<Trainee> getAllTraineeDetails() {
		// TODO Auto-generated method stub
		return dao.getAllTraineeDetails();
	}



	@Override
	public Trainee getTraineeById(int traineeId) {
		// TODO Auto-generated method stub
		return dao.getTraineeById(traineeId);
	}



	@Override
	public boolean deleteTraineeById(int traineeId) {
		// TODO Auto-generated method stub
		return dao.deleteTraineeById(traineeId);
	}



	@Override
	public boolean updateTrainee(Trainee trainee) {
		// TODO Auto-generated method stub
		return dao.updateTrainee(trainee);
	}

	
}
