package com.cg.trainee.service;

import java.util.ArrayList;

import com.cg.trainee.dto.Login;
import com.cg.trainee.dto.Trainee;

public interface TraineeService {
	
	public boolean validateUser(Login lg);
	public Login getUserById(String username);
	public Trainee addTrainee(Trainee trainee);
	public ArrayList<Trainee> getAllTraineeDetails();
	public Trainee getTraineeById(int traineeId);
	public boolean deleteTraineeById(int traineeId);
	public boolean updateTrainee(Trainee trainee);

}
