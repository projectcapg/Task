package com.cg.trainee.dao;

import java.util.ArrayList;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.transaction.Transactional;

import org.springframework.stereotype.Component;

import com.cg.trainee.dto.Login;
import com.cg.trainee.dto.Trainee;

@Component
@Transactional
public class TraineeDaoImpl implements TraineeDao{

	
	@PersistenceContext
	EntityManager em;
	@Override
	public Login getUserById(String username) {
		// TODO Auto-generated method stub
		Login user=em.find(Login.class, username);
		return user;
	}
	@Override
	public Trainee addTrainee(Trainee trainee) {
		// TODO Auto-generated method stub
		em.persist(trainee);
		Trainee train=em.find(Trainee.class, trainee.getTraineeId());
		return train;
	}
	@Override
	public ArrayList<Trainee> getAllTraineeDetails() {
		// TODO Auto-generated method stub
		String qry="SELECT train FROM Trainee train";
		TypedQuery<Trainee> query=em.createQuery(qry,Trainee.class);
		ArrayList<Trainee> list=(ArrayList<Trainee>) query.getResultList();
		return list;
	}
	@Override
	public Trainee getTraineeById(int traineeId) {
		// TODO Auto-generated method stub
		Trainee train=em.find(Trainee.class, traineeId);
		return train;
	}
	@Override
	public boolean deleteTraineeById(int traineeId) {
		// TODO Auto-generated method stub
		Trainee del=em.find(Trainee.class, traineeId);
		em.remove(del);
		return true;
	}
	@Override
	public boolean updateTrainee(Trainee trainee) {
		// TODO Auto-generated method stub
		boolean status=false;
		Trainee found=em.find(Trainee.class, trainee.getTraineeId());
		found.setTraineeName(trainee.getTraineeName());
		found.setTraineeDomain(trainee.getTraineeDomain());
		found.setTraineeLocation(trainee.getTraineeLocation());
		status=true;
		return status;
	}

}
