import { Injectable } from '@angular/core';
import { Employee } from './employee';
import { UpdateemployeeComponent } from './updateemployee/updateemployee.component';

@Injectable({
  providedIn: 'root'
})
export class EmployeeService {
  private employees: Employee[] = [{ id: 1001, name: 'Rahul', salary: 9000, dept: 'Java' },
  { id: 1002, name: 'Sachin', salary: 19000, dept: 'OraApps' },
  { id: 1003, name: 'Vikash', salary: 29000, dept: 'BI' },
  ];
  index: number;
  emp: Employee;


  constructor() { }

  getEmployees(): Employee[] {
    return this.employees;
  }
  addEmployee(emp: Employee) {
    this.employees.push(emp);
    return true;
  }

  deleteEmployee(i: number) {
    this.employees.splice(i, 1);
  }

  setIndex(i) {
    this.index = i;
    return this.emp = this.getEmployee(i);
  }
  getIndex() {
    return this.index;
  }
  getEmployee(i) {
    return this.employees[i];
  }

  update1(emp) {
    this.employees[this.employees.indexOf[emp]] = emp;
  } // Update Function
}
