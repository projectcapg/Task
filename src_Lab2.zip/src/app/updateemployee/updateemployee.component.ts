import { Component, OnInit } from '@angular/core';
import { Employee } from '../employee';
import { EmployeeService } from '../employee.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-updateemployee',
  templateUrl: './updateemployee.component.html',
  styleUrls: ['./updateemployee.component.css']
})
export class UpdateemployeeComponent implements OnInit {

  emp: Employee = { id: null, name: '', salary: null, dept: '' }; // Initializing a book object which will store the updated details

  constructor(private service: EmployeeService, private router: Router) { } // Initializing objects of service and Router classes

  ngOnInit() {
    this.emp = this.service.getEmployee(this.service.getIndex());
    // Intializing the book object using the index obtained from the service class
  }

  update() {
    this.service.update1(this.emp);
  } // Calling the Update function in the service class and navigating to the show page
}
