import { Component, OnInit } from '@angular/core';
import { Employee } from '../employee';
import { EmployeeService } from '../employee.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-showemployee',
  templateUrl: './showemployee.component.html',
  styleUrls: ['./showemployee.component.css']
})
export class ShowemployeeComponent implements OnInit {

  employees: Employee[];
  emp: Employee = { id: null, name: '', salary: null, dept: '' };

  constructor(private empService: EmployeeService, private router: Router) { }

  ngOnInit() {
    this.employees = this.empService.getEmployees();
  }
  delete(i: number) {
    this.empService.deleteEmployee(i);
  }

  update(i) {
    this.empService.setIndex(i);
    this.emp = this.empService.getEmployee(this.empService.getIndex());
  }

  update1() {
    this.empService.update1(this.emp);
  }

}
