package com.cg.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class MyServlet
 */
@WebServlet("/MyServlet")
public class MyServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public MyServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String qstr=request.getParameter("action");
		if(qstr.equals("login"))
		{
			RequestDispatcher dispatch=request.getRequestDispatcher("Login.jsp");
			dispatch.forward(request, response);
		}
		else
		{
			RequestDispatcher dispatch=request.getRequestDispatcher("register.jsp");
			dispatch.forward(request, response);
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		String qstr= request.getParameter("action");
		if(qstr.equals("loginUser"))
		{
			String user= request.getParameter("uName");
			String pass= request.getParameter("pwd");
			if(user.equals("CG") && pass.equals("123"))
			{
				response.sendRedirect("success.jsp");
			}
			else
				response.sendError(401,"Invalid Credentials");
		}
		else
		{
			String user= request.getParameter("uName");
			String addrs= request.getParameter("addrs");
			String pass= request.getParameter("pwd");
			ServletContext context=this.getServletContext();
			context.setAttribute("user", user);
			context.setAttribute("addrs", addrs);
			context.setAttribute("pass", pass);
			response.sendRedirect("user.jsp");
		}
	}

}
