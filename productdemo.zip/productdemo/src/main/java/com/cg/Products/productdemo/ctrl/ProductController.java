package com.cg.Products.productdemo.ctrl;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cg.Products.productdemo.dto.Product;
import com.cg.Products.productdemo.exception.ProductNotFoundException;
import com.cg.Products.productdemo.service.ProductService;






@RestController
public class ProductController {
	
	@Autowired
	ProductService prodS;
	
	@PostMapping(value="/addProduct",consumes=MediaType.APPLICATION_JSON_VALUE,headers="Accept=application/json",
			produces=MediaType.APPLICATION_JSON_VALUE)
	public Product createUserDetail(@RequestBody Product prod)
	{
		prodS.addProduct(prod);
		Product p=prodS.getProductByProductId(prod.getProd_id());

		return p;
	}
	
	@RequestMapping(value="/showAllProducts",method=RequestMethod.GET,headers="Accept=application/json")
	public ArrayList<Product> showAllProducts()
	{
		System.out.println("--------UserRestController---showAllUsers called------------------");
		return prodS.getAllProducts();
	}
	
	@GetMapping(value="searchProduct/{uid}") 
	public Product searchUserDetailById(@PathVariable("uid") int uid) throws ProductNotFoundException
	{
		Product prod=prodS.getProductByProductId(uid);
		if(prod==null)
		{
			throw new ProductNotFoundException("No Product with this Id");
		}
		else
		{
		return prod;
		}
	}
	
	@DeleteMapping(value="/deleteProduct/{uid}",headers="Accept=application/json")
	
	public String deleteUser(@PathVariable("uid") int id) throws ProductNotFoundException
	{
		Product prod=prodS.getProductByProductId(id);
		if(prod==null)
		{
			throw new ProductNotFoundException("No Product with this Id");
		}
		else
		{
		prodS.deleteProductByProductId(id);
		return ("Data Deleted...");
		}
		
	}

	@PutMapping(value="/ProductUpdate/",consumes=MediaType.APPLICATION_JSON_VALUE, headers="Accept=application/json")
	public void updateUser(@RequestBody Product prod) 
	{
		prodS.updateProduct(prod.getProd_name(), prod.getProd_price(), prod.getProd_id());
		System.out.println("Data updated successfully!");
	}
}
