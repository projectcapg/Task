package com.cg.Products.productdemo.service;

import java.util.ArrayList;

import com.cg.Products.productdemo.dto.Product;



public interface ProductService {

	public ArrayList<Product> getAllProducts();
	public Product addProduct(Product prod);
	public Product getProductByProductId(int id);
	public void deleteProductByProductId(int id);
	public void updateProduct(String newname,double newprice, int id);
}
