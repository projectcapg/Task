package com.cg.Products.productdemo.dao;

import java.util.ArrayList;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.cg.Products.productdemo.dto.Product;



@Repository
@Transactional
public interface ProductRepositry extends JpaRepository<Product, String>{
	
	@Query("SELECT products FROM Product products")
	public ArrayList<Product> getAllProducts();
    
	@Query("SELECT product FROM Product product WHERE product.prod_id = :uid")
	public Product getProductByProductId(@Param("uid") int uid);
	
	@Transactional
	@Modifying
	@Query("DELETE FROM Product prod WHERE prod.prod_id=:uid")
	public void deleteProductByProductId(@org.springframework.data.repository.query.Param("uid") int id);
	
	@Modifying
	@Query("UPDATE Product prod SET prod.prod_name=:name,prod.prod_price=:price WHERE prod.prod_id=:uid")
	public void updateProduct(@Param("name") String name, @Param("price") double price,@Param("uid") int id);

}
