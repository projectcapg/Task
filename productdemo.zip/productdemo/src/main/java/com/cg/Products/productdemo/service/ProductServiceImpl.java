package com.cg.Products.productdemo.service;

import java.util.ArrayList;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.Products.productdemo.dao.ProductRepositry;
import com.cg.Products.productdemo.dto.Product;

@Service
@Transactional
public class ProductServiceImpl implements ProductService{
	
	@Autowired
	ProductRepositry prodDao;

	@Override
	public ArrayList<Product> getAllProducts() {
		// TODO Auto-generated method stub
		return prodDao.getAllProducts();
	}

	@Override
	public Product addProduct(Product prod) {
		// TODO Auto-generated method stub
		return prodDao.save(prod);
	}

	@Override
	public Product getProductByProductId(int id) {
		// TODO Auto-generated method stub
		return prodDao.getProductByProductId(id);
	}

	@Override
	public void deleteProductByProductId(int id) {
		// TODO Auto-generated method stub
		prodDao.deleteProductByProductId(id);
	}

	@Override
	public void updateProduct(String newname, double newprice, int id) {
		// TODO Auto-generated method stub
		prodDao.updateProduct(newname, newprice, id);
		
	}
	
	

}
