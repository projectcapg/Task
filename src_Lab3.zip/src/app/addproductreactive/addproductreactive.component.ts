import { Component, OnInit } from '@angular/core';
import { Product } from '../product';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';

@Component({
  selector: 'app-addproductreactive',
  templateUrl: './addproductreactive.component.html',
  styleUrls: ['./addproductreactive.component.css']
})
export class AddproductreactiveComponent implements OnInit {

  prod: Product = { id: null, name: '', cost: null };
  prodForm: FormGroup;
  status = 'Invalid';
  constructor(private formBuilder: FormBuilder) { }

  ngOnInit() {
    this.prodForm = this.formBuilder.group({
      id: ['', Validators.required, '', Validators.pattern('[0-9]{1,}')],
      name: ['', Validators.required, '', Validators.pattern('[A-Za-z]{1,}')],
      cost: ['', Validators.required, '', Validators.pattern('[0-9]{1,}')],
    });
  }

  add() {
    this.prod = this.prodForm.value;
    this.status = 'INVALID';
    if (this.prodForm.invalid) {
      return;
    } else {
      this.status = 'Valid';
    }
  }

}
