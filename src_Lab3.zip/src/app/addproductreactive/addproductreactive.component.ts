import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-addproductreactive',
  templateUrl: './addproductreactive.component.html',
  styleUrls: ['./addproductreactive.component.css']
})
export class AddproductreactiveComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
