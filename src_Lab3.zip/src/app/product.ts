export class Product {

}
