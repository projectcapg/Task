package com.cg.service;

import java.util.ArrayList;

import com.cg.dao.BillDao;
import com.cg.dao.BillDaoImpl;
import com.cg.dto.BillDetails;
import com.cg.dto.Consumers;
import com.cg.exception.EBillException;

public class BillServiceImpl implements BillService{
	
	BillDao dao;
	 public BillServiceImpl()
	 {
		 dao=new BillDaoImpl();
	 }

	@Override
	public ArrayList<Consumers> getConsumers() throws EBillException {
		// TODO Auto-generated method stub
		return dao.getConsumers();
	}

	@Override
	public BillDetails addBill(BillDetails bill) throws EBillException {
		// TODO Auto-generated method stub
		return dao.addBill(bill);
	}

	@Override
	public ArrayList<BillDetails> ShowBill(int consumer_num) throws EBillException {
		// TODO Auto-generated method stub
		return dao.ShowBill(consumer_num);
	}

	@Override
	public Consumers getConsumerById(int consumer_num) throws EBillException {
		// TODO Auto-generated method stub
		return dao.getConsumerById(consumer_num);
	}

	@Override
	public String getName(int consumer_num) throws EBillException {
		// TODO Auto-generated method stub
		return dao.getName(consumer_num);
	}

}
