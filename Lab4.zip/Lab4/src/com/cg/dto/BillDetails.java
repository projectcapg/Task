package com.cg.dto;

import java.time.LocalDate;

public class BillDetails {

	int bill_num;
	int consumer_num;
	float curr_reading;
	float unit_consumed;
	float net_amount;
	LocalDate bill_date;
	public int getBill_num() {
		return bill_num;
	}
	public BillDetails(int bill_num, int consumer_num, float curr_reading,
			float unit_consumed, float net_amount, LocalDate bill_date) {
		super();
		this.bill_num = bill_num;
		this.consumer_num = consumer_num;
		this.curr_reading = curr_reading;
		this.unit_consumed = unit_consumed;
		this.net_amount = net_amount;
		this.bill_date = bill_date;
	}
	public void setBill_num(int bill_num) {
		this.bill_num = bill_num;
	}
	public int getConsumer_num() {
		return consumer_num;
	}
	public void setConsumer_num(int consumer_num) {
		this.consumer_num = consumer_num;
	}
	public float getCurr_reading() {
		return curr_reading;
	}
	public void setCurr_reading(float curr_reading) {
		this.curr_reading = curr_reading;
	}
	public float getUnit_consumed() {
		return unit_consumed;
	}
	public void setUnit_consumed(float unit_consumed) {
		this.unit_consumed = unit_consumed;
	}
	public float getNet_amount() {
		return net_amount;
	}
	public void setNet_amount(float net_amount) {
		this.net_amount = net_amount;
	}
	public LocalDate getBill_date() {
		return bill_date;
	}
	public void setBill_date(LocalDate bill_date) {
		this.bill_date = bill_date;
	}
	public BillDetails(int bill_num, int consumer_num, float curr_reading,
			float unit_consumed, float net_amount) {
		super();
		this.bill_num = bill_num;
		this.consumer_num = consumer_num;
		this.curr_reading = curr_reading;
		this.unit_consumed = unit_consumed;
		this.net_amount = net_amount;
		this.bill_date=LocalDate.now();
	}
	public BillDetails(int consumer_num, float curr_reading, float unit_consumed) {
		super();
		this.consumer_num = consumer_num;
		this.curr_reading = curr_reading;
		this.unit_consumed = unit_consumed;
		this.bill_date=LocalDate.now();
	}
	public BillDetails() {
		super();
	}
	@Override
	public String toString() {
		return "BillDetails [bill_num=" + bill_num + ", consumer_num="
				+ consumer_num + ", curr_reading=" + curr_reading
				+ ", unit_consumed=" + unit_consumed + ", net_amount="
				+ net_amount + ", bill_date=" + bill_date + "]";
	}
	
	
}
