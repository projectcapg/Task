package com.cg.dao;

import java.util.ArrayList;

import com.cg.dto.BillDetails;
import com.cg.dto.Consumers;
import com.cg.exception.EBillException;

public interface BillDao {
	
	public ArrayList<Consumers> getConsumers() throws EBillException;
	public BillDetails addBill(BillDetails bill) throws EBillException;
	public ArrayList<BillDetails> ShowBill(int consumer_num) throws EBillException;
	public Consumers getConsumerById(int consumer_num) throws EBillException;
	public String getName(int consumer_num) throws EBillException;

}
