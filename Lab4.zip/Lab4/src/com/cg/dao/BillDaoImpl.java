package com.cg.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

import com.cg.dto.BillDetails;
import com.cg.dto.Consumers;
import com.cg.exception.EBillException;
import com.cg.util.DBUtil;
import com.cg.util.MyStringDateUtil;

public class BillDaoImpl implements BillDao{
	
	Connection con;

	public BillDaoImpl()
	{
		con=DBUtil.getConnection();
	}

	@Override
	public ArrayList<Consumers> getConsumers() throws EBillException{
		// TODO Auto-generated method stub
		ArrayList<Consumers> list=new ArrayList<Consumers>();
		String qry="SELECT * FROM Consumers ORDER BY CONSUMER_NUM";
		Consumers consumer=null;
		try
		{
			Statement st=con.createStatement();
			ResultSet rs=st.executeQuery(qry);
			
			while(rs.next())
			{
				consumer= new Consumers(rs.getInt(1),rs.getString(2),rs.getString(3));
				list.add(consumer);
			}
		}
		catch(Exception e)
		{
			throw new EBillException(e.getMessage());
		}
		return list;
	}

	@Override
	public BillDetails addBill(BillDetails bill) throws EBillException {
		// TODO Auto-generated method stub
		BillDetails ref=null;
		float amount=(float) ((bill.getUnit_consumed()*1.15)+100);
		String qry="INSERT INTO BillDetails VALUES(seq_bill_num.nextval,?,?,?,?,?)";
		try
		{
			PreparedStatement st=con.prepareStatement(qry);
			st.setInt(1, bill.getConsumer_num());
			st.setFloat(2, bill.getCurr_reading());
			st.setFloat(3, bill.getUnit_consumed());
			st.setFloat(4, amount);
			st.setDate(5, MyStringDateUtil.fromLocalToSqlDate(bill.getBill_date()));
			bill.setNet_amount(amount);
			int row=st.executeUpdate();
			if(row>0)
			{
				ref=bill;
			}
		}
		catch(Exception e)
		{
			throw new EBillException(e.getMessage());
		}
		return ref;
	}

	@Override
	public ArrayList<BillDetails> ShowBill(int consumer_num) throws EBillException {
		// TODO Auto-generated method stub
		BillDetails ref=null;
		ArrayList<BillDetails> list=new ArrayList<BillDetails>();
		String qry="SELECT * FROM BillDetails WHERE consumer_num=? ORDER BY bill_num";
		try
		{
			PreparedStatement st=con.prepareStatement(qry);
			st.setInt(1, consumer_num);
			ResultSet rs=st.executeQuery();
			if(rs.next()==false)
			{
				list=null;
			}
			else
			{
			ref=new BillDetails(rs.getInt(1),rs.getInt(2),rs.getFloat(3),rs.getFloat(4),rs.getFloat(5),MyStringDateUtil.fromSqlToLocalDate(rs.getDate(6)));
			list.add(ref);
			while(rs.next())
			{
				ref=new BillDetails(rs.getInt(1),rs.getInt(2),rs.getFloat(3),rs.getFloat(4),rs.getFloat(5),MyStringDateUtil.fromSqlToLocalDate(rs.getDate(6)));
				list.add(ref);
			}
		}
		}
		catch(Exception e)
		{
			throw new EBillException(e.getMessage());
		}
		return list;
	}

	@Override
	public Consumers getConsumerById(int consumer_num) throws EBillException {
		// TODO Auto-generated method stub
		Consumers ref=null;
		String qry="SELECT * FROM Consumers WHERE consumer_num=?";
		try
		{
			PreparedStatement st=con.prepareStatement(qry);
			st.setInt(1, consumer_num);
			ResultSet rs=st.executeQuery();
			if(rs.next())
			{
				ref=new Consumers(rs.getInt(1),rs.getString(2),rs.getString(3));
			}
		}
		catch(Exception e)
		{
			throw new EBillException(e.getMessage());
		}
		return ref;
	}

	@Override
	public String getName(int consumer_num) throws EBillException {
		// TODO Auto-generated method stub
		String name=null;
		String qry="SELECT consumer_name FROM Consumers WHERE consumer_num=?";
		try
		{
			PreparedStatement st=con.prepareStatement(qry);
			st.setInt(1, consumer_num);
			ResultSet rs=st.executeQuery();
			if(rs.next())
			{
				name=rs.getString(1);
			}
		}
		catch(Exception e)
		{
			throw new EBillException(e.getMessage());
		}
		return name;
	}

}
