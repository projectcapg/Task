package com.cg.controller;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.cg.dto.BillDetails;
import com.cg.dto.Consumers;

import com.cg.exception.EBillException;
import com.cg.service.BillService;
import com.cg.service.BillServiceImpl;

/**
 * Servlet implementation class BillServlet
 */
@WebServlet("/BillServlet")
public class BillServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	BillService service=null;
	int con_num=0;
    /**
     * @see HttpServlet#HttpServlet()
     */
    public BillServlet() {
        super();
        service= new BillServiceImpl();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		HttpSession session=request.getSession(true);
		
		String qStr= request.getParameter("action");
		if(qStr.equals("showAll"))
		{
			ArrayList<Consumers> list;
			try {
				list = service.getConsumers();
				session.setAttribute("conlist", list);
				RequestDispatcher dispatch= request.getRequestDispatcher("showAll.jsp");
				dispatch.forward(request, response);
			}
			catch (EBillException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		else if(qStr.equals("showById"))
		{
			RequestDispatcher dispatch= request.getRequestDispatcher("showById.jsp");
			dispatch.forward(request, response);
			
		}
		else if(qStr.equals("showBill"))
		{
			String consumer_id= request.getParameter("id");
			con_num=Integer.parseInt(consumer_id);
			session.setAttribute("con_num", con_num);
			try {
				ArrayList<BillDetails> list=service.ShowBill(con_num);
				if(list==null)
				{
					RequestDispatcher dispatch= request.getRequestDispatcher("error.jsp");
					dispatch.forward(request, response);
				}
				System.out.println(list);
				session.setAttribute("bList", list);
				RequestDispatcher dispatch= request.getRequestDispatcher("show_bills.jsp");
				dispatch.forward(request, response);
			} catch (EBillException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		else if(qStr.equals("generateBill"))
		{
			RequestDispatcher dispatch= request.getRequestDispatcher("generateBill.jsp");
			dispatch.forward(request, response);
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		HttpSession session=request.getSession(false);
		String qStr= request.getParameter("action");
		if(qStr.equals("searchById"))
		{
			if(request.getParameter("id").isEmpty())
			{
				String id="is empty";
				session.setAttribute("con_num", id);
				RequestDispatcher dispatch= request.getRequestDispatcher("errorConsumer.jsp");
				dispatch.forward(request, response);
			}
			else
			{
			String conId= request.getParameter("id");
			con_num= Integer.parseInt(conId);
			Consumers con;
			try {
				con = service.getConsumerById(con_num);
				session.setAttribute("con_num", con_num);
				if(con==null)
				{
				RequestDispatcher dispatch= request.getRequestDispatcher("errorConsumer.jsp");
				dispatch.forward(request, response);
				}
				session.setAttribute("conById", con);
				RequestDispatcher dispatch= request.getRequestDispatcher("success.jsp");
				dispatch.forward(request, response);
			}
			catch (EBillException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			}
		}
		else if(qStr.equals("insertBill"))
		{
			
			try {
				String last_reading= request.getParameter("lRead");
				String curr_reading= request.getParameter("cRead");
				int last= Integer.parseInt(last_reading);
				int curr= Integer.parseInt(curr_reading);
				int amount=curr-last;
				if(amount<0)
				{
				RequestDispatcher dispatch= request.getRequestDispatcher("errorMeter.jsp");
				dispatch.forward(request, response);
				}
				else
				{
				BillDetails bill=new BillDetails(con_num,curr,amount);
				BillDetails ref;
				ref = service.addBill(bill);
				String name=service.getName(con_num);
				if(ref!=null)
				{
					session.setAttribute("bill", ref);
					session.setAttribute("name", name);
					RequestDispatcher dispatch= request.getRequestDispatcher("billInfo.jsp");
					dispatch.forward(request, response);
				}
			}
			}catch (EBillException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}
	}

}
