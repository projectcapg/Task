import { Directive, ElementRef } from '@angular/core';

@Directive({
  selector: '[appTxtchange]'
})
export class TxtchangeDirective {

  constructor(e: ElementRef) {
    e.nativeElement.style = 'background-color: skyblue; color: red';
  }

}
