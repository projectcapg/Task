import { Component, OnInit, Output, EventEmitter } from '@angular/core';
import { Customer } from '../model/customer';
import { CustomerService } from '../service/customer.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-searchcustomer',
  templateUrl: './searchcustomer.component.html',
  styleUrls: ['./searchcustomer.component.css']
})
export class SearchcustomerComponent implements OnInit {


  selectedVal;
  cust: Customer;
  customers: Customer[];
  searched: Customer[];
  t = 0;

  constructor(private custService: CustomerService, private router: Router) { this.custService = custService; }


  ngOnInit() {
    this.customers = this.custService.getAllCustomers();
  }
 /* search(s) {
    // tslint:disable-next-line: prefer-for-of
    this.cust = this.custService.searchbyID(s);
  }*/
  filterData(value: string) {
    this.searched = this.customers.filter(customer => customer.name.toLowerCase() === (value.toLowerCase()));
    this.custService.setSearchedData(this.searched);
    if (this.searched.length > 0) {
      alert('Data found!');
      this.router.navigate(['showsearch']);
    } else {
      alert('not found please try with other names');
    }
  }

}
