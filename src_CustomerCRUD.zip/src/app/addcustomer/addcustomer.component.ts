import { Component, OnInit } from '@angular/core';
import { Customer } from '../model/customer';
import { CustomerService } from '../service/customer.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-addcustomer',
  templateUrl: './addcustomer.component.html',
  styleUrls: ['./addcustomer.component.css']
})
export class AddcustomerComponent implements OnInit {
  cust: Customer = { id: null, name: '', email: '', phone: null };
  constructor(private custService: CustomerService, private router: Router) { }

  ngOnInit() {
  }
  add() {
    this.custService.addCustomer(this.cust);
    alert('Customer Added Succesfully');
    this.router.navigate(['list']); // for automatic navigation
  }

}
