import { Component, OnInit } from '@angular/core';
import { CustomerService } from '../service/customer.service';
import { Customer } from '../model/customer';

@Component({
  selector: 'app-showsearchedcomponent',
  templateUrl: './showsearchedcomponent.component.html',
  styleUrls: ['./showsearchedcomponent.component.css']
})
export class ShowsearchedcomponentComponent implements OnInit {
  searchedData: Customer[];

  constructor(private service: CustomerService) { }

  ngOnInit() {
    this.searchedData = this.service.getSearch();
  }

}
