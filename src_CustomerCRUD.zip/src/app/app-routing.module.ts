import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { CustomerlistComponent } from './customerlist/customerlist.component';
import { AddcustomerComponent } from './addcustomer/addcustomer.component';
import { SearchcustomerComponent } from './searchcustomer/searchcustomer.component';
import { AddReactiveComponent } from './add-reactive/add-reactive.component';
import { ShowsearchedcomponentComponent } from './showsearchedcomponent/showsearchedcomponent.component';
import { UpdatecomponentComponent } from './updatecomponent/updatecomponent.component';


const routes: Routes = [
  { path: '', redirectTo: 'add', pathMatch: 'full' }, // default page if no path is selected
  { path: 'list', component: CustomerlistComponent }, { path: 'add', component: AddcustomerComponent },
  { path: 'search', component: SearchcustomerComponent },
  {path: 'addReactive', component: AddReactiveComponent},
  {path: 'showsearch', component: ShowsearchedcomponentComponent},
  {path: 'update', component: UpdatecomponentComponent}

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
