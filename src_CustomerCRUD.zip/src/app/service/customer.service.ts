import { Injectable } from '@angular/core';
import { Customer } from '../model/customer';
import { HttpClient } from '@angular/common/http'; // important to import
import { Observable, throwError } from 'rxjs';
import { retry, catchError } from 'rxjs/operators';


@Injectable({
  providedIn: 'root'
})
export class CustomerService {
  url = '../assets/customer.json';
  customers: Customer[];
  status: string;
  filterData: Customer[];
  filter: Customer;
  customer: Customer;
  index: number;
  constructor(private http: HttpClient) {
    this.getCustomers();
  } // initializing the Http object

  getData(): Observable<Customer[]> {
    return this.http.get<Customer[]>(this.url).pipe(retry(2), catchError(this.handleError));
  } // send the Http request to get the array of customers from the json file

  handleError(error) {
    console.log(error);
    return throwError(error);
  } // error handling ex 404 error etc

  getCustomers() {
    this.getData().subscribe((data: Customer[]) => this.customers = data);
    console.log('Data: ' + this.customers);
  } // convert into customers array

  getAllCustomers() {
    return this.customers;
  }
  deleteCustomer(i) {
    this.customers.splice(i, 1);
  }
  addCustomer(customer: Customer) {
    this.customers.push(customer);
  }
  setSearchedData(data) {
    this.filterData = data;
  }
  getSearch() {
    return this.filterData;
  }
  searchbyID(id) {
    // tslint:disable-next-line: prefer-for-of
    for (let i = 0; i < this.customers.length; i++) {

      if (this.customers[i].id === id) {
        this.filter = this.customers[i];
        break;
      }
    }
    return this.filter;
  }

  setIndex(i) {
    this.index = i;
  }
  getIndex() {
    return this.index;
  }
  getCustomer(i) {
    return this.customers[i];
  }
  update(customer) {
    this.customers[this.customers.indexOf[customer]] = customer;
  }
}
