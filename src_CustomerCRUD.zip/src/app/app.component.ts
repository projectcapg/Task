import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'CustomerCRUD';
  name = 'HaRi gAlLa';
  dob = new Date(1997, 9, 25);
  salary = 65545.54679234;
}
