import { TxtchangeDirective } from './txtchange.directive';

describe('TxtchangeDirective', () => {
  it('should create an instance', () => {
    const directive = new TxtchangeDirective();
    expect(directive).toBeTruthy();
  });
});
